#include <stdio.h>
#include <math.h>

int main(void) {
  int X;
  
  printf("Digite um valor para X:\n");
  scanf("%d", &X);

  //Formula
  double resultado = (X = 5 * X + 3/ sqrt((2 * 2) - 16));

  //Resultado
  printf("Esse e o resultado: %lf", resultado);
  return 0;
}