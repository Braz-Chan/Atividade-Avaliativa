#include <stdio.h>
#include <string.h>

int main() {
    int total_cidades = 200;
    int maior_indice_acidentes = 0, menor_indice_acidentes = 0;
    char cidade_maior_acidentes[50], cidade_menor_acidentes[50];
    int total_veiculos = 0, total_acidentes_rs = 0, num_cidades_rs = 0;

    for (int i = 1; i <= total_cidades; i++) {
        char estado[3];
        int veiculos, acidentes;

        printf("Informe o estado da cidade %d: ", i);
        scanf("%s", estado);

        printf("Informe o número de veículos de passeio da cidade %d: ", i);
        scanf("%d", &veiculos);
        total_veiculos += veiculos;

        printf("Informe o número de acidentes de trânsito com vítimas da cidade %d: ", i);
        scanf("%d", &acidentes);

        // Verifica o maior e o menor índice de acidentes
        if (i == 1 || acidentes > maior_indice_acidentes) {
            maior_indice_acidentes = acidentes;
            strcpy(cidade_maior_acidentes, estado);
        }

        if (i == 1 || acidentes < menor_indice_acidentes) {
            menor_indice_acidentes = acidentes;
            strcpy(cidade_menor_acidentes, estado);
        }

        // Verifica se a cidade pertence ao Rio Grande do Sul (RS)
        if (strcmp(estado, "RS") == 0) {
            total_acidentes_rs += acidentes;
            num_cidades_rs++;
        }
    }

    // Calcula a média de veículos nas cidades brasileiras
    float media_veiculos = (float)total_veiculos / total_cidades;

    // Calcula a média de acidentes com vítimas entre as cidades do Rio Grande do Sul
    float media_acidentes_rs = (float)total_acidentes_rs / num_cidades_rs;

    printf("a) Maior índice de acidentes de trânsito: %d em %s\n", maior_indice_acidentes, cidade_maior_acidentes);
    printf("   Menor índice de acidentes de trânsito: %d em %s\n", menor_indice_acidentes, cidade_menor_acidentes);
    printf("b) Média de veículos nas cidades brasileiras: %.2f\n", media_veiculos);
    printf("c) Média de acidentes com vítimas no Rio Grande do Sul: %.2f\n", media_acidentes_rs);

    return 0;
}

