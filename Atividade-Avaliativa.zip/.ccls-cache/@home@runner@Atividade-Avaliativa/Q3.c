#include <stdio.h>

int main() {
    float A, B, C;

    // Solicita ao usuário para inserir os comprimentos dos lados
    printf("Insira os comprimentos dos lados do triângulo (A, B, C): ");
    scanf("%f %f %f", &A, &B, &C);

    // Verifica se os lados formam um triângulo
    if (A + B > C && A + C > B && B + C > A) {
        // Verifica se é um triângulo equilátero
        if (A == B && B == C) {
            printf("É um triângulo equilátero.\n");
        }
        // Verifica se é um triângulo isósceles
        else if (A == B || A == C || B == C) {
            printf("É um triângulo isósceles.\n");
        }
        // Caso contrário, é um triângulo escaleno
        else {
            printf("É um triângulo escaleno.\n");
        }
    } else {
        printf("Não é um triângulo.\n");
    }

    return 0;
}
