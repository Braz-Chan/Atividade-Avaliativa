#include <stdio.h>

int main() {
    float A, B, C;
    float maior, menor, meio;

    // Solicita ao usuário para inserir os comprimentos dos lados
    printf("Insira os comprimentos dos lados do triângulo (A, B, C): ");
    scanf("%f %f %f", &A, &B, &C);

    // Encontre o maior, o menor e o lado do meio
    if (A > B) {
        maior = A;
        menor = B;
        meio = C;
    } else {
        maior = B;
        menor = A;
        meio = C;
    }

    if (C > maior) {
        meio = maior;
        maior = C;
    } else if (C < menor) {
        meio = menor;
        menor = C;
    }

    // Verifica se os lados formam um triângulo
    if (maior < menor + meio) {
        // Verifica se é um triângulo retângulo
        if (maior * maior == menor * menor + meio * meio) {
            printf("É um triângulo retângulo.\n");
        }
        // Verifica se é um triângulo obtusângulo
        else if (maior * maior > menor * menor + meio * meio) {
            printf("É um triângulo obtusângulo.\n");
        }
        // Caso contrário, é um triângulo acutângulo
        else {
            printf("É um triângulo acutângulo.\n");
        }
    } else {
        printf("Não é um triângulo.\n");
    }

    return 0;
}
