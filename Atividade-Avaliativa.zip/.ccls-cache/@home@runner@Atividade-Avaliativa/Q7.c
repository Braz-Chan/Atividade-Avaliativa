#include <stdio.h>

int main() {
    int num_alunos = 30;
    float notas[num_alunos];
    float media_geral = 0.0;

    // Loop para ler as notas e calcular as médias ponderadas de cada aluno
    for (int i = 0; i < num_alunos; i++) {
        float n1, n2, n3;
        printf("Informe as notas do aluno %d (n1 n2 n3): ", i + 1);
        scanf("%f %f %f", &n1, &n2, &n3);

        // Calcula a média ponderada do aluno
        float media_ponderada = (n1 * 2 + n2 * 4 + n3 * 3) / 10;
        notas[i] = media_ponderada;
        media_geral += media_ponderada;

        // Verifica se o aluno foi aprovado ou reprovado
        if (media_ponderada >= 7.0) {
            printf("Aluno %d: Média %.2f - Aprovado\n", i + 1, media_ponderada);
        } else {
            printf("Aluno %d: Média %.2f - Reprovado\n", i + 1, media_ponderada);
        }
    }

    // Calcula a média geral da turma
    media_geral /= num_alunos;
    printf("Média geral da turma: %.2f\n", media_geral);

    return 0;
}
