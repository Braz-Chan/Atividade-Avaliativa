#include <stdio.h>

int main() {
    float salario, total_salario = 0, media_salario, maior_salario = 0;
    int num_pessoas = 0, num_filhos, total_filhos = 0;
    int num_pessoas_salario_ate_100 = 0;

    do {
        // Solicita ao usuário que insira o salário
        printf("Insira o salário (ou um valor negativo para encerrar): ");
        scanf("%f", &salario);

        // Verifica se o salário é negativo (condição de saída)
        if (salario < 0) {
            break;
        }

        // Solicita ao usuário que insira o número de filhos
        printf("Insira o número de filhos: ");
        scanf("%d", &num_filhos);

        // Atualiza as estatísticas
        total_salario += salario;
        total_filhos += num_filhos;
        num_pessoas++;

        // Verifica se o salário é até R$100,00
        if (salario <= 100.0) {
            num_pessoas_salario_ate_100++;
        }

        // Verifica se este é o maior salário encontrado até agora
        if (salario > maior_salario) {
            maior_salario = salario;
        }
    } while (1);

    // Calcula as médias
    media_salario = total_salario / num_pessoas;
    float media_filhos = (float)total_filhos / num_pessoas;

    // Calcula o percentual de pessoas com salário até R$100,00
    float percentual_salario_ate_100 = (float)num_pessoas_salario_ate_100 / num_pessoas * 100.0;

    // Exibe os resultados
    printf("a) Média do salário da população: %.2f\n", media_salario);
    printf("b) Média do número de filhos: %.2f\n", media_filhos);
    printf("c) Maior salário: %.2f\n", maior_salario);
    printf("d) Percentual de pessoas com salário até R$100,00: %.2f%%\n", percentual_salario_ate_100);

    return 0;
}
